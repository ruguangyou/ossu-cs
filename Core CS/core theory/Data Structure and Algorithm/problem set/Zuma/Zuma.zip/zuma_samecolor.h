#pragma once

template <typename T> ZumaNode<T>* Zuma<T>::sameColor(ZumaNode<T>* p) {
	if (p == NULL) return NULL;
	while (p != first() && p->pred->color == p->color) p = p->pred;
	if (p != last() && p->succ != last() && p->color == p->succ->succ->color) return p;
	else return NULL;
}